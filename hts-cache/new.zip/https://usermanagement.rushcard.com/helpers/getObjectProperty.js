<head><title>Document Moved</title></head>
<body><h1>Object Moved</h1>This document may be found <a HREF="https://usermanagement.rushcard.com/helpers/getobjectproperty.js">here</a></body>